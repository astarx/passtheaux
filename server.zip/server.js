var express = require('express');
var app = express();
var bodyParser = require('body-parser');
//var itunesApiSearch = require('itunes-api-search');
var Client = require('node-rest-client').Client;

var port = process.env.PORT || 8080;

app.use(bodyParser.json());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// set the static files location /public/img will be /img for users
app.use(express.static(__dirname + '/public'));

var client = new Client();

client.get("https://itunes.apple.com/search?term=jack+johnson&media=music&limit=5", function(data, response) {
    // parsed response body as js object 
    //console.log(data);
    // raw response 
    var obj = JSON.parse(data);

    var song = {
        id: obj.results[0].artistId
    }
    console.log('data: ' + obj.results[0].artistId);
});

app.get('/song/:name', function(req, res) {
    client.get("https://itunes.apple.com/search?term=" + req.params.name + "&media=music&limit=5", function(data, response) {
        // parsed response body as js object 
        //console.log(data);
        // raw response 
        var obj = JSON.parse(data);

        var song = {
            id: obj.results[0].artistId
        }
        console.log('data: ' + obj.results[0]);
        res.setHeader('Content-Type', 'application/json');
        res.json(obj);
    });
});

// itunesApiSearch.search(term, options, callback) 

// itunesApiSearch.search('rock', {
//     entity: 'music',
//     limit: 100, // max 200 
//     country: 'US'
// }, function(err, res) {
//     if (err) {
//         console.log("error" + JSON.stringify(err));
//         return;
//     } else
//         console.log("response" + res);
// });

// start app ===============================================
// startup our app at http://localhost:8080
app.listen(port);


// shoutout to the user                     
console.log('shit is happening on port ' + port);

// expose app           
exports = module.exports = app;